Blusas=prompt("Digite a quantidade de blusas");
la=Blusas*7;
novelos="Total de novelos: "+la;
alert(novelos);