b1=prompt("Digite o tamanho da base menor do trapezio (m)");
b2=prompt("Digite o tamanho da base maior do trapezio (m)");
h=prompt("Digite a altura do trapezio (m)");
area=(b1+b2)*h/2;
alert("A area total do trapézio é "+area+"m² ");

