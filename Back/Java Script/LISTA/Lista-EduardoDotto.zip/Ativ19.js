l=prompt("Informe o lado do quadrado (em metros)");
area=l*l;
alert("Area do quadrado é "+area+"m²");