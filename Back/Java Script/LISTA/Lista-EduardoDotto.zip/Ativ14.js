preco=prompt("Digite o preço do produto");
novopreco=preco*0.9
alert("Desconto " + novopreco);
