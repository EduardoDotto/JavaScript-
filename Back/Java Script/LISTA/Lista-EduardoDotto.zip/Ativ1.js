quantidade=prompt("Digite a quantidade de hamburgueres a serem feitos");
queijo=quantidade*2*0.05;
presunto=quantidade*0.05;
burguer=quantidade*0.1;
total="Sao necessários "+queijo+" quilogramas de queijo, "+presunto+" quilogramas de presunto e "+burguer+" quilogramas de carne";
alert(total);