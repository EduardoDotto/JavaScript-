h1=prompt("Insira a altura");
s1=prompt("Insira o comprimento de sua sombra");
s2=prompt("Insira o comprimento da sombra do predio");
h2=s2*h1/s1;
Predio=h2+" m";
alert(Predio);
