salario=prompt("Informe o salario do funcionario");
vendas=prompt("Informe o total das vendas");
Total=0.04*vendas+parseInt(salario);
alert("O salario final do funcionario eh: "+Total.toFixed(2));

