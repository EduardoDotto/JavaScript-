tempC=prompt("Digite a temperatura em Celsius:");
tempF=(tempC*9/5)+32;
result="Temperatura em Fahrenheit: "+tempF;
alert(result);