minimo=prompt("Informe o valor do salario minimo");
salario=prompt("Informe seu salario");
total=salario/minimo;
alert("Você recebe "+total.toFixed(2)+" salarios minimos");