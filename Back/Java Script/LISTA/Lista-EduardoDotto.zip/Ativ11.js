n1=prompt("Informe o primeiro numero");
n2=prompt("Informe o segundo numero");
n3=prompt("Informe o terceiro numero");
Multi=n1*n2*n3;
alert("A multiplicação é: "+Multi);