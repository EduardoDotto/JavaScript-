altura=prompt("Informe a altura da caixa de agua");
raio=prompt("Informe o raio da caixa de agua");
volume=3.14*raio*raio*altura;
alert("O volume da caixa da água é: "+volume.toFixed(2)+"L");
