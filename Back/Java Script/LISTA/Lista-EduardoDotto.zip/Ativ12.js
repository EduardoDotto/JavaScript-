n1=prompt("Digite o primeiro numero");
n2=prompt("Digite o segundo numero");
div=n1/n2;
alert(div.toFixed(2));