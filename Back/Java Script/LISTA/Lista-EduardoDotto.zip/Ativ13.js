n1=prompt("Digite a primeira nota");
n2=prompt("Digite a segunda nota");
med=(n1*2+n2*3)/5;
alert(med);