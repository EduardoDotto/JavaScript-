peso=prompt("Digite o seu peso (kg)");
magro=peso*0.8;
gordo=peso*1.15;
alert("Se engordar 15%: "+gordo.toFixed(2)+"kg Se emarecer 20%: "+magro.toFixed(2)+"kg");