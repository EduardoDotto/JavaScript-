Frango=prompt("Informe a quantidade de frangos na granja Frangotech");
Total=Frango*(4+2*3.5);
result="Custo total: "+Total;
alert(result);