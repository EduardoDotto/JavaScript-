l1=prompt("Informe a diagonal maior");
l2=prompt("Informe a diagonal menor");
area=l1*l2/2;
alert("A área do um losango é "+area+" m²");
