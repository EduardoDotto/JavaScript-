Litro=prompt("Informe quantos litros de refresco deseja fazer?");
agua=0.8*Litro;
suco=0.2*Litro;
Total="Serão necessários "+agua+" l de agua e "+suco+" l de suco de maracuja";
alert(Total);