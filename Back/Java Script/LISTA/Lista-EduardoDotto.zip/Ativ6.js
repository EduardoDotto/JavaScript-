Pouco=prompt("Digite a quantidade de latas (350mL)");
Medio=prompt("Digite a quantidade de garrafas (600mL)");
Grande=prompt("Digite a quantidade de garrafas (2L)");
Litros=Pouco*0.35+Medio*0.6+Grande*2;
result="Litros: "+Litros;
alert(result);

