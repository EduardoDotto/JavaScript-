Valor=1200-(200*1.02)-(120*1.02);
alert("Joao tera de pagar R$"+Valor.toFixed(2));