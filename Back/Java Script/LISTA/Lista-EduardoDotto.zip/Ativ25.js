co=prompt("Insira o valor do cateto oposto");
ca=prompt("Insira o valor do cateto adjacente");
hipotenusa=Math.sqrt(Math.pow(co,2)+Math.pow(ca,2));
alert("A hipotenusa é "+hipotenusa.toFixed(2));

