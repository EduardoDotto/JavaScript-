n=prompt("Digite um numero inteiro para a tabuada");
result=" ";
for(i=0;i<=10;i++)
{
    result=result+i*n+", ";
}
alert(result);

